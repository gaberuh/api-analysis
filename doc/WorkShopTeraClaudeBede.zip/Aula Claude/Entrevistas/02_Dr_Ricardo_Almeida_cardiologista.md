# Transcrição de Entrevista — Dr. Ricardo Almeida

**Data:** 14/05/2026
**Duração:** 62 minutos
**Perfil:** Cardiologista, 47 anos, clínica com 3 médicos em BH (Savassi), 22 anos de formado
**Produtos:** Whitebook (semanal), iClinic (diário), ReceitaPro (diário)
**Entrevistador:** Pesquisador UX — Equipe Cross AI, Afya SPM

---

**Entrevistador:** Ricardo, obrigado por participar. Me conta um pouco sobre seu consultório.

**Dr. Ricardo:** Tenho uma clínica de cardiologia com mais dois colegas. São 3 consultórios, uma secretária, e uma técnica de enfermagem. Atendo de segunda a sexta, em média 12-15 pacientes por dia. Consultas de cardiologia são mais longas — 30 a 40 minutos cada.

**Entrevistador:** Há quanto tempo usa iClinic?

**Dr. Ricardo:** Uns 4 anos. Antes usava prontuário em papel, acredite. Demorei para migrar porque tinha medo de perder dados. Quando migrei, sofri, mas hoje não volto atrás. O problema é que o iClinic promete muito e entrega... 70%. Esses 30% que faltam me fazem perder tempo todo dia.

**Entrevistador:** Pode detalhar esses 30%?

**Dr. Ricardo:** Vou te dar o exemplo mais absurdo. Mês passado, o sistema de pagamento deu problema. Não conseguia gerar boleto para os pacientes de convênio particular. Fiquei 3 dias com o financeiro travado. Mandei mensagem pro suporte — demoraram 48 horas para responder. Enquanto isso, a secretária teve que fazer tudo na mão, em planilha. Quando resolveram, simplesmente disseram "foi um bug no sistema de pagamento, já corrigimos". Sem explicação, sem compensação, sem garantia de que não vai acontecer de novo.

**Entrevistador:** Isso afetou a confiança no sistema?

**Dr. Ricardo:** Muito. Porque quando o financeiro falha, eu perco dinheiro literalmente. Paciente que não recebe o boleto não paga. E eu não posso ficar ligando para cobrar. Depois desse episódio, comecei a pesquisar concorrentes. Vi o Feegow, vi o Amigo Tech. Não troquei ainda porque a migração de 4 anos de prontuários me assusta. Mas estou com um pé fora.

**Entrevistador:** E no dia a dia clínico, como o iClinic funciona?

**Dr. Ricardo:** O prontuário em si é bom. Eu customizei meus modelos de anamnese cardiológica — história da doença atual, fatores de risco cardiovascular, exame físico dirigido, eletrocardiograma, ecocardiograma quando aplicável. Isso funciona. O que não funciona é a transcrição por voz.

**Entrevistador:** Me conta mais sobre a transcrição.

**Dr. Ricardo:** Eu tentei usar por dois meses. Desisti. O motivo principal: termos cardiológicos. Eu falo "bloqueio atrioventricular de segundo grau tipo Mobitz I" e o sistema escreve algo irreconhecível. Falo "insuficiência mitral moderada com jato excêntrico" e ele entende "insuficiência digital moderada com jato esférico". Não é aceitável. Num prontuário médico, um erro desses pode causar problema legal. Se o paciente processar e o prontuário tiver um dado errado por causa da transcrição, quem responde sou eu.

**Entrevistador:** Você acha que a transcrição funciona para algum cenário?

**Dr. Ricardo:** Para queixas simples, sim. "Paciente refere dor torácica há 2 dias, localizada em região precordial, sem irradiação." Isso ele transcreve bem. Mas cardiologia não é simples. Metade das minhas consultas envolve interpretação de exames complementares com terminologia específica. E aí a transcrição desmorona.

**Entrevistador:** E o Whitebook, como entra na sua rotina?

**Dr. Ricardo:** Eu uso menos que deveria, admito. Uso quando estou com dúvida sobre interação medicamentosa — cardiologia tem muitas. Paciente que toma anticoagulante, anti-hipertensivo, estatina, antiarrítmico — são 4 a 6 medicações simultâneas. Verificar interação de todas é inviável de cabeça. Aí o Whitebook ajuda.

**Entrevistador:** Já usou o WBIA para isso?

**Dr. Ricardo:** Usei umas 3 vezes. Na primeira, perguntei sobre combinação de amiodarona com rivaroxabana. A resposta foi boa — explicou o risco de aumento do efeito anticoagulante, sugeriu monitoramento mais frequente. E veio com citação, o que me deu confiança. Nas outras vezes, as respostas foram genéricas demais. Tipo, perguntei sobre manejo de fibrilação atrial em paciente com insuficiência renal estágio 3b, e a resposta parecia de manual básico de clínica médica, não de cardiologia. Não tinha profundidade suficiente para um especialista.

**Entrevistador:** Então o WBIA funciona melhor para clínica geral do que para especialidades?

**Dr. Ricardo:** Essa é a minha impressão. E isso faz sentido — provavelmente a base de dados é mais robusta para condições comuns. Mas eu sou cardiologista. Preciso de profundidade. Se a IA me der a mesma resposta que um R1 de clínica médica daria, não me ajuda. Eu preciso que ela vá além — que considere as nuances, as exceções, os guidelines mais recentes de 2025.

**Entrevistador:** Vamos falar de prescrição. Como é com o ReceitaPro?

**Dr. Ricardo:** O ReceitaPro é o que eu mais uso no dia a dia. Prescrevo anticoagulantes, anti-hipertensivos, estatinas... A maioria tem dose fixa, então é relativamente simples. Mas tenho dois problemas graves.

**Entrevistador:** Quais?

**Dr. Ricardo:** Primeiro: ajuste de dose renal. Muitos dos meus pacientes têm insuficiência renal associada. A dose de dabigatrana, por exemplo, muda conforme o clearance de creatinina. O ReceitaPro não me alerta sobre isso. Eu sei porque sou especialista, mas e se um clínico geral prescrevesse? O sistema deveria avisar: "Atenção: para ClCr entre 30-50, a dose recomendada é X." Isso é segurança do paciente.

Segundo: interações medicamentosas na prescrição. Eu prescrevo amiodarona e o paciente já toma varfarina — o sistema deveria avisar que a interação é grave. Mas não avisa. Zero alertas. Eu preciso verificar isso manualmente no Whitebook. São dois sistemas que deveriam conversar e não conversam.

**Entrevistador:** Sobre a integração entre os produtos — como avalia?

**Dr. Ricardo:** Fragmentada. São três produtos da mesma empresa e parecem três empresas diferentes. Eu estou no iClinic, preciso verificar uma dose no Whitebook — abro outro app, faço outra busca, acho a informação, volto pro iClinic, digito manualmente na prescrição. É como ter três assistentes que não conversam entre si. Um sabe meu prontuário, outro sabe de medicamentos, outro sabe de referência médica. Mas nenhum passa informação para o outro. É frustrante porque a Afya tem TODAS as peças. Só não juntou.

**Entrevistador:** Se a Afya integrasse tudo em uma experiência única, como seria?

**Dr. Ricardo:** O cenário ideal: eu estou no prontuário do iClinic, escrevo o diagnóstico "fibrilação atrial". O sistema automaticamente me sugere: (1) protocolo de tratamento do Whitebook, (2) prescrição pré-montada do ReceitaPro com anticoagulante ajustado pela função renal do paciente, (3) alerta de interações com as medicações que ele já usa. Tudo na mesma tela, sem trocar de app. Isso sim seria IA útil. Não preciso de chatbot — preciso de inteligência contextual.

**Entrevistador:** O que te faria sentir mais seguro com a IA no geral?

**Dr. Ricardo:** Transparência. Quando a IA me sugere algo, eu preciso saber: (1) de onde veio essa informação, (2) qual o nível de evidência, (3) quando foi atualizado. Se não tem essas três coisas, eu não confio. Não é birra — é responsabilidade profissional. Eu respondo judicialmente pelo que prescrevo. Se uma IA me induzir a um erro, quem vai pro Cremeb sou eu, não a Afya.

**Entrevistador:** Última pergunta: o que te faria virar um promotor dos produtos da Afya?

**Dr. Ricardo:** Resolvam a integração. Se Whitebook, iClinic e ReceitaPro funcionassem como um único produto inteligente que entende meu paciente, minhas consultas, e minha especialidade — eu indicaria para todo colega que conheço. Hoje, eu digo: "usa o iClinic, mas se prepara pra se frustrar com umas coisas". Não é o tipo de recomendação que vocês querem.

**Entrevistador:** Ricardo, muito obrigado. Isso foi extremamente útil.

**Dr. Ricardo:** Disponha. E desculpa se fui duro — é porque eu realmente gosto dos produtos e vejo o potencial. Só falta... juntar as pontas.

---
*Entrevista encerrada. 62 minutos.*
