# Reviews da App Store — App Grana
## Material para Atividade de Discovery (Módulo 4)

---

⭐ (1 estrela) — @usuario_frustrado
"App bonito mas inútil. Configura meta, esquece, abre 1 mês depois e tá tudo vermelho. Prefiro o Mobills."

---

⭐⭐ (2 estrelas) — @mariapj
"Boa ideia mas não funciona pra quem é PJ. Renda variável não existe nesse app."

---

⭐⭐⭐ (3 estrelas) — @joao_dev
"Ajudou no começo mas depois parou de me engajar. Falta notificação, falta gamificação, falta motivo pra abrir."

---

⭐⭐⭐⭐ (4 estrelas) — @carol_savings
"Uso todo dia. A meta automática é muito boa. Só falta mostrar o progresso de forma mais visual. Quero ver o gráfico subindo, sabe?"

---

⭐⭐⭐⭐⭐ (5 estrelas) — @pedro_simples
"Finalmente um app que não me faz sentir burro. Simples, direto, sem jargão de investidor."
