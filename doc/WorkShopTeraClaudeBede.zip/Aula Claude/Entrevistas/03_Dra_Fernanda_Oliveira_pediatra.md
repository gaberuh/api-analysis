# Transcrição de Entrevista — Dra. Fernanda Oliveira

**Data:** 15/05/2026
**Duração:** 55 minutos
**Perfil:** Pediatra, 31 anos, atende em clínica multiespecialidade em Fortaleza, 5 anos de formada
**Produtos:** Whitebook (diário), iClinic (diário), ReceitaPro (diário)
**Entrevistador:** Pesquisador UX — Equipe Cross AI, Afya SPM

---

**Entrevistador:** Fernanda, pode começar contando como é sua rotina?

**Dra. Fernanda:** Atendo em uma clínica com mais 8 médicos de diferentes especialidades. Somos todos autônomos que compartilham a estrutura. Eu atendo 20 pacientes por dia — é puxado, mas pediatria tem consultas mais curtas em geral. O desafio é que metade dos meus pacientes são lactentes e pré-escolares, então a mãe fica nervosa, a criança chora, e eu preciso ser rápida E precisa ao mesmo tempo.

**Entrevistador:** E como os produtos Afya te ajudam nesse contexto?

**Dra. Fernanda:** O Whitebook é minha Bíblia. Não exagero. Eu atendo pediatria geral — desde puericultura até emergência pediátrica. A amplitude é enorme. Não tem como decorar dose de todos os antibióticos para todas as faixas etárias e todos os pesos. O Whitebook me salva nisso todo dia.

**Entrevistador:** Usa mais a busca ou o WBIA?

**Dra. Fernanda:** A busca quando preciso de uma informação pontual — dose, diluição, intervalo. O WBIA quando tenho uma dúvida mais contextual. Tipo, mãe que pergunta: "Doutora, meu filho de 2 anos pode tomar mel?" Eu sei que não pode antes de 1 ano por causa do botulismo, mas depois de 1 ano tem nuances. Aí pergunto pro WBIA e ele me dá uma resposta que eu posso adaptar para explicar pra mãe em linguagem simples.

**Entrevistador:** Como avalia a qualidade das respostas do WBIA para pediatria?

**Dra. Fernanda:** Uns 70% das vezes é excelente. Mas tem um problema sério: quando eu pergunto sobre doses pediátricas, às vezes a resposta vem com a dose adulta. Tipo, pergunto "dose de azitromicina para otite média em criança de 3 anos" e a resposta começa falando da dose adulta de 500mg, e só depois menciona a pediátrica. Para mim que sou pediatra, sei filtrar. Mas imagina um clínico geral que está inseguro — ele pode pegar a primeira informação e prescrever dose adulta para uma criança. Isso é perigoso.

**Entrevistador:** Como isso poderia ser resolvido?

**Dra. Fernanda:** A IA deveria saber que EU sou pediatra. Se o meu CLAUDE.md ou meu perfil diz que sou pediatra, a resposta deveria vir primeiro com a dose pediátrica, estratificada por faixa etária e peso. Dose adulta nem deveria aparecer a menos que eu peça. Isso é personalização básica que faria uma diferença enorme na segurança.

**Entrevistador:** Faz sentido. E o "Also Asked" do Whitebook?

**Dra. Fernanda:** Adoro. Em pediatria é especialmente útil porque as mães fazem perguntas que eu não tinha pensado. Tipo, eu pesquiso "tratamento de IVAS em criança" e aparece "Quando encaminhar para otorrinolaringologista?" e "IVAS de repetição: quantos episódios justificam investigação?". Essas perguntas sugeridas me fazem parecer mais preparada na frente da mãe. E muitas vezes antecipam a próxima pergunta que ela ia fazer.

**Entrevistador:** Agora sobre o iClinic. Como é para pediatria?

**Dra. Fernanda:** O iClinic não foi feito para pediatria. Pronto, falei. O prontuário é genérico — funciona bem para adulto, mas para criança faltam campos essenciais. Não tem campo dedicado para curva de crescimento. Não tem cálculo automático de percentil. Não tem gráfico de peso × idade integrado ao prontuário. Eu tenho que usar o app da OMS separado para plotar a curva e depois anotar manualmente no iClinic: "Peso no percentil 50, estatura no percentil 25." É anacrônico.

**Entrevistador:** Você já reportou isso?

**Dra. Fernanda:** Várias vezes. A resposta é sempre "está no nosso roadmap". Mas faz 2 anos que está no roadmap. Enquanto isso, eu perco 3 minutos por consulta de puericultura fazendo um cálculo que deveria ser automático. Com 8 pueroculturas por dia, são 24 minutos perdidos. Multiplicar por 220 dias úteis... faz a conta. É tempo de vida que eu estou jogando fora.

**Entrevistador:** E a transcrição por voz no iClinic?

**Dra. Fernanda:** Uso e gosto. Para pediatria funciona relativamente bem porque o vocabulário é menos complexo que cardiologia ou neurologia. Mas tem um problema: quando a criança está chorando no fundo, o microfone capta o choro e a transcrição fica uma bagunça. Acontece em 40% das consultas. Eu precisaria de um filtro de ruído mais inteligente, ou pelo menos a opção de pausar e retomar sem perder o que já foi transcrito.

**Entrevistador:** Muito prático. E o ReceitaPro na pediatria?

**Dra. Fernanda:** Aqui é onde eu mais sofro. A calculadora de posologia é o que mais falta. Eu prescrevo por peso em 90% das vezes. Amoxicilina: 50mg/kg/dia dividido em 3 doses. Criança pesa 14kg. Então: 14 × 50 = 700mg por dia, dividido por 3 = 233mg por dose. A suspensão vem em 250mg/5ml. Então: 233 ÷ 250 × 5 = 4,66ml. Arredondo para 5ml. Faço essa conta na cabeça ou na calculadora do celular para CADA prescrição pediátrica. São 15 prescrições por dia. É insano. O ReceitaPro deveria fazer isso automaticamente — eu coloco o peso, seleciono a medicação, e ele calcula.

**Entrevistador:** Isso já foi mencionado por outros médicos que entrevistamos.

**Dra. Fernanda:** Não me surpreende. Todo pediatra sofre com isso. E olha que a conta que eu fiz é simples — para antibióticos é direto. Agora tenta calcular dose de anticonvulsivante em lactente com peso de 4,5kg. Aí a margem de erro é ainda mais perigosa.

**Entrevistador:** Sobre a busca de medicamentos no ReceitaPro?

**Dra. Fernanda:** Funciona razoavelmente. Mas falta uma coisa: formulações pediátricas. Quando eu busco "ibuprofeno", aparece comprimido de 400mg e 600mg primeiro. A suspensão pediátrica aparece depois de rolar para baixo. Deveria priorizar a formulação pediátrica se eu sou pediatra, ou se o paciente tem menos de 12 anos. De novo: personalização.

**Entrevistador:** E a integração entre os produtos?

**Dra. Fernanda:** Inexistente para meu caso de uso. Cenário ideal: eu faço puericultura no iClinic, registro peso e altura, o sistema calcula automaticamente o percentil e plota na curva de crescimento. Se o peso estiver abaixo do percentil 3, sugere: "Deseja consultar protocolo de investigação de baixo peso no Whitebook?" E quando eu prescrevo vitamina D ou sulfato ferroso, o ReceitaPro já calcula a dose pelo peso que acabei de registrar. Tudo conectado. Hoje, cada etapa é manual e em apps diferentes.

**Entrevistador:** Se pudesse mudar uma coisa em cada produto?

**Dra. Fernanda:** Whitebook: respostas do WBIA priorizadas pela minha especialidade. Se sou pediatra, dose pediátrica primeiro. Sempre.

iClinic: curva de crescimento integrada ao prontuário. Com cálculo automático de percentil.

ReceitaPro: calculadora de posologia pediátrica. Sem isso, o produto está incompleto para 15% dos médicos do Brasil que são pediatras.

**Entrevistador:** Última pergunta: você recomenda os produtos Afya?

**Dra. Fernanda:** Recomendo o Whitebook sem hesitar. É o melhor em PT-BR, disparado. O iClinic eu recomendo com ressalvas: "é bom, mas não espere features pediátricas." O ReceitaPro eu recomendo, mas aviso: "vai precisar de calculadora do lado."

O que me entristece é que seria tão fácil resolver. Não estou pedindo IA generativa complexa. Estou pedindo uma multiplicação. Peso × dose/kg ÷ concentração. É conta de quinta série. Mas ninguém implementou.

**Entrevistador:** Fernanda, obrigado demais. Vou levar isso diretamente para o time de produto.

**Dra. Fernanda:** Obrigada vocês por ouvirem. Faz tempo que queria falar isso para alguém que realmente vai usar.

---
*Entrevista encerrada. 55 minutos.*
