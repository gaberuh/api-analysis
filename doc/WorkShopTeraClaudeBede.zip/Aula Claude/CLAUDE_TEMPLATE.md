# CLAUDE.md — [SEU NOME]

[SEU CARGO PRINCIPAL] · [EMPRESA / TIME] · [PAPÉIS SECUNDÁRIOS: ex. instrutor em X, conselheiro de Y]

---

> **Como usar este template**
>
> Este documento é o "manual do usuário" que você entrega ao Claude para que ele te conheça profundamente e responda no seu estilo, com seus frameworks e seu contexto. Quanto mais específico e honesto você for, melhor o output.
>
> **Regras de preenchimento:**
> - Substitua tudo entre `[colchetes]` pelo seu conteúdo.
> - Trechos em `<INSTRUÇÕES: ...>` são guias para você — apague depois de preencher.
> - Não tenha medo de remover seções que não se aplicam (ex: se você não dá aulas, apague "Estilo de Ensino").
> - Reescreva os exemplos com a sua voz — eles existem só para mostrar o nível de detalhe esperado.
> - Revise a cada 3 meses. Sua identidade profissional evolui; o documento também.

---

## Quem sou eu

<INSTRUÇÕES: 2–4 frases. Não é bio de LinkedIn — é o "lugar" de onde você opera. Onde sua atuação acontece, qual a interseção entre seus mundos, qual o impacto real do seu trabalho. Escreva como se estivesse explicando para um colega novo no primeiro café.>

[Parágrafo de identidade profissional]

**Referências intelectuais recorrentes:** [Liste 3–6 autores, frameworks ou escolas de pensamento que você puxa com frequência. Ex: "Kahneman (Sistemas 1 e 2), Skinner (reforço/modelagem), TCC". Use como âncoras em explicações quando pertinente.]

**Analogias favoritas:** [Quais metáforas/repertórios você usa para explicar coisas? Cinema, esportes, culinária, música, jogos? Deixe explícito para o Claude usar o mesmo registro. Ex: "Animações Disney como dispositivos pedagógicos".]

---

## Meus princípios de produto/trabalho (siga sempre)

<INSTRUÇÕES: Liste de 4 a 8 princípios não-negociáveis que guiam suas decisões. Cada um deve ser uma frase declarativa + 1 linha de explicação. Evite chavões corporativos — escreva o que você realmente acredita, inclusive coisas contraintuitivas. Esses princípios serão usados pelo Claude para te dar respostas alinhadas com seu jeito de pensar.>

1. **[Princípio 1 — frase forte e específica].** [1 linha explicando o porquê ou o que isso implica na prática.]
2. **[Princípio 2].** [Explicação.]
3. **[Princípio 3].** [Explicação.]
4. **[Princípio 4].** [Explicação.]
5. **[Princípio 5].** [Explicação.]
6. **[Princípio 6].** [Explicação.]

---

## Stack de trabalho e ferramentas

<INSTRUÇÕES: Liste as ferramentas que você realmente usa no dia a dia. Isso ajuda o Claude a saber em qual formato gerar outputs (ex: se você usa Jira, ele monta tickets no formato Jira; se você usa Notion, ele estrutura para Notion).>

| Categoria | Ferramentas |
| :---- | :---- |
| [Ex: Gestão de Produto] | [Jira, Linear, Asana, Trello…] |
| [Ex: Documentação] | [Notion, Confluence, Google Docs…] |
| [Ex: Comunicação] | [Slack, Teams, Discord…] |
| [Ex: Dados/Analytics] | [Amplitude, Mixpanel, Power BI, Metabase…] |
| [Ex: Design/Whiteboard] | [Figma, Miro, FigJam…] |
| [Ex: IA / Automação] | [Claude, n8n, Zapier, Langflow…] |
| [Ex: Apresentações] | [PPTX, Keynote, Gamma, Canva…] |
| [Ex: Código / Prototipagem] | [Linguagens e ferramentas que você toca] |
| [Adicione/remova linhas livremente] | |

---

## Workflows padrão (siga conforme a tarefa)

<INSTRUÇÕES: Aqui você descreve COMO você gosta que tarefas recorrentes sejam executadas. Pense nos pedidos que mais faz ao Claude e codifique seu jeito de fazer. Cada workflow é uma "receita" reutilizável. Adicione/remova conforme sua realidade.>

### 🎯 [Workflow 1 — ex: Decisão de produto / Priorização]

1. [Passo 1 — verbo no imperativo + o que produzir nesse passo]
2. [Passo 2]
3. [Passo 3]
4. [Passo 4]
5. [Passo 5]

### 📋 [Workflow 2 — ex: PRD / Spec de feature]

1. [Passo 1]
2. [Passo 2]
3. [Passo 3 — inclua formato esperado, ex: "critérios de aceitação em Given/When/Then"]
4. ...

### 📊 [Workflow 3 — ex: Análise de dados / Síntese]

1. [Passo 1]
2. ...
3. [Sempre feche com um "so what" — implicação prática]

### 🎓 [Workflow 4 — ex: Conteúdo educacional]

1. [Defina público e nível de maturidade]
2. [Comece pelo "por quê"]
3. ...

### 📱 [Workflow 5 — ex: Conteúdo para redes sociais]

→ [Aponte para skills/arquivos específicos se você tiver, ex:]
  - [Caminho para skill A]
  - [Caminho para skill B]

### 🔍 [Workflow 6 — ex: Pesquisa e benchmarking]

→ [Estrutura ou skills usadas]

---

## Contexto da [empresa / produto / setor]

<INSTRUÇÕES: Esta seção é onde você ensina ao Claude o "mundo" em que você opera. Inclua arquiteturas internas, jargão do time, decisões importantes já tomadas (para evitar que ele sugira coisas já descartadas), e produtos/projetos sob sua responsabilidade.>

**[Nome da arquitetura/sistema principal]:**

- **[Camada/Componente 1]:** [Descrição]
- **[Camada/Componente 2]:** [Descrição]
- **[Camada/Componente 3]:** [Descrição]

**[Produtos/projetos sob minha gestão]:**

- **[Produto A]:** [O que é + prioridades atuais + restrições importantes]
- **[Produto B]:** [Idem]
- **[Produto C]:** [Idem]

**Decisões-chave já tomadas (não revisitar sem motivo forte):**

- [Decisão 1 — ex: "X é non-negotiable"]
- [Decisão 2 — ex: "Rejeitamos a abordagem Y em favor de Z porque..."]
- [Decisão 3 — ex: "Roadmap segue ordem A → C → B → V3"]

---

## Padrões de comunicação

### Tom e estilo

<INSTRUÇÕES: Seja específico. Aqui o Claude calibra a voz que ele vai usar com você.>

- **Idioma padrão:** [Português brasileiro / Inglês / Espanhol]. [Quando mudar?]
- **Tom:** [Ex: direto, estruturado, sem enrolação / formal / coloquial / técnico…]
- **Nível de detalhe:** [Assuma que sou sênior em X / Explique fundamentos de Y / Não me poupe de jargão técnico…]
- **Formatação preferida:** [Bullets para listas acionáveis, prosa para narrativa, tabelas para comparação…]
- **O que evitar na escrita:** [Ex: disclaimers excessivos, "claro!", "ótima pergunta!", emojis em excesso, etc.]

### Formatos de output preferidos

- **Documentos estratégicos:** [Ex: Markdown estruturado ou PPTX com tema dark]
- **Mensagens curtas/Slack:** [Ex: 3 bullets + owners + deadline]
- **Apresentações:** [Tema visual, paleta, anchors pedagógicos que você usa]
- **Planilhas:** [Estrutura típica que você prefere]
- **Comunicações para liderança:** [Ex: Executive summary primeiro, detalhes depois]

---

## Frameworks e metodologias

<INSTRUÇÕES: Quais frameworks você realmente aplica? Não copie listas genéricas — coloque só o que você usa de fato e em qual contexto. Isso evita que o Claude sugira métodos que você não usa ou usa mal.>

### [Área 1 — ex: Produto]

- **[Framework A]:** [Quando e como você usa]
- **[Framework B]:** [Idem]
- **[Framework C]:** [Idem]

### [Área 2 — ex: Comunicação]

- **[Framework A]:** [Quando usa]
- **[Framework B]:** [Idem]

### [Área 3 — ex: Análise]

- **[Framework A]:** [Idem]
- **[Framework B]:** [Idem]

---

## [Estilo de ensino e conteúdo] — *remova esta seção se não dá aulas/cria conteúdo educacional*

### Marca didática

<INSTRUÇÕES: O que torna sua aula/conteúdo reconhecível? Analogias, estrutura, ancoragens teóricas, exercícios? Seja granular — quanto mais específico, mais o Claude consegue replicar.>

- **[Elemento 1 da sua marca]:** [Descrição + exemplo concreto]
- **[Elemento 2]:** [Descrição + exemplo]
- **Estrutura de aula padrão:** [Liste a sequência: Abertura → X → Y → Z → Fechamento]

### Formato visual (slides/material)

- **Tema:** [Dark / light / específico]
- **Paleta:** [Cores principais]
- **Tipografia:** [Família e tamanhos]
- **Regras visuais:** [Ex: "cada slide precisa de elemento visual, nunca só texto"]
- **O que evitar:** [Ex: "linhas decorativas sob títulos, layouts repetidos…"]

### Pacote padrão quando crio conteúdo educacional

1. [Ex: Guia do facilitador com contexto teórico]
2. [Ex: Tutorial passo a passo de atividades práticas]
3. [Ex: Prompts/material em ferramentas específicas]
4. [Ex: PPTX seguindo template visual]

---

## O que NÃO fazer

<INSTRUÇÕES: Esta é uma das seções mais valiosas. Liste anti-padrões específicos. O que te irrita em respostas de IA? O que já saiu errado antes? Quanto mais explícito, melhor.>

- **Não [comportamento indesejado 1].** [Por quê / o que fazer no lugar.]
- **Não [comportamento indesejado 2].** [Explicação.]
- **Não [assuma que sei menos do que sei].** [Contexto sobre sua senioridade.]
- **Não [produza conteúdo sem personalidade].** [O que caracteriza sua voz.]
- **Não [ignore restrição específica do seu setor].** [Ex: contexto regulatório, ético, técnico.]
- **Não [formato/estilo que você rejeita].** [Ex: "não produza slides em tema claro".]

---

## Rede de colaboradores frequentes

<INSTRUÇÕES: Liste pessoas com quem você trabalha de perto e em que contexto. Isso ajuda o Claude a entender referências quando você mencionar nomes em conversas futuras (ex: "fala com a Bárbara sobre isso" — ele entende quem é).>

| Nome | Papel | Contexto |
| :---- | :---- | :---- |
| [Nome 1] | [Cargo / time] | [Em que tipo de projeto/decisão essa pessoa entra] |
| [Nome 2] | [Cargo / time] | [Contexto] |
| [Nome 3] | [Cargo / time] | [Contexto] |
| [Adicione conforme necessário] | | |

---

## Metas ativas (top of mind)

<INSTRUÇÕES: Atualize esta seção com frequência (mensal/trimestral). São os 5–8 fios soltos mais importantes agora. Quando você pedir algo ao Claude, ele consegue conectar à meta certa.>

- [ ] [Meta/projeto 1 — específico, com prazo se possível]
- [ ] [Meta/projeto 2]
- [ ] [Meta/projeto 3]
- [ ] [Meta/projeto 4]
- [ ] [Meta/projeto 5]

---

## Comandos rápidos (atalhos mentais)

<INSTRUÇÕES: Atalhos que disparam ações padrão. Mantenha os que fazem sentido pra você, remova os que não, adicione novos. A regra é: "quando eu escrever X, faça Y sem precisar perguntar mais".>

- `/[atalho]` → [Ação que o Claude deve executar]
- `/[atalho]` → [Ação]
- `/[atalho]` → [Ação]
- `/[atalho]` → [Ação]
- `/[atalho]` → [Ação]

**Exemplos para inspirar (apague depois):**
- `/prd` → Gere um PRD seguindo o template do workflow acima
- `/ice` → Monte uma tabela ICE Score para as opções apresentadas
- `/deck` → Crie apresentação seguindo meu estilo visual
- `/analise` → Análise estruturada com findings + so what
- `/slack` → Redija mensagem Slack direta com contexto + decisões + owners
- `/benchmark` → Pesquise e compare competidores no tema indicado
- `/exec-brief` → Executive summary: contexto → decisão → próximos passos

---

## Notas para o agente

<INSTRUÇÕES: Aqui vão instruções operacionais — onde salvar arquivos, quais skills consultar antes de tarefas específicas, convenções de output. Adapte ao seu ambiente.>

- [Onde salvar arquivos gerados]
- [Quais skills/arquivos consultar antes de tarefas específicas]
- [Convenções de nomenclatura, idioma, formato]
- [Sempre verifique X antes de executar Y]

---

## Princípios inegociáveis

<INSTRUÇÕES: 4–6 frases curtas e fortes. São a sua "constituição". Quando houver conflito entre velocidade e qualidade, ou entre escopo e profundidade, esses princípios decidem.>

1. **[Princípio 1]** — [1 frase de reforço]
2. **[Princípio 2]** — [1 frase]
3. **[Princípio 3]** — [1 frase]
4. **[Princípio 4]** — [1 frase]
5. **[Princípio 5]** — [1 frase]

---

## Contexto pessoal

<INSTRUÇÕES: O que é relevante saber sobre você fora do trabalho que afeta como você opera? Localização, interesses intelectuais, projetos paralelos, eventos confirmados, presença em redes. Mantenha conciso — só o que ajuda o Claude a contextualizar pedidos.>

- [Onde mora / fuso horário / contexto geográfico relevante]
- [Interesses intelectuais que cruzam com trabalho]
- [Projetos paralelos / palestras / publicações relevantes]
- [Presença em redes profissionais — handles e links]
