# Transcrição de Entrevista — Dr. Carolina Mendes

**Data:** 14/05/2026
**Duração:** 58 minutos
**Perfil:** Clínica geral, 34 anos, consultório próprio em SP (Moema), 6 anos de formada
**Produtos:** Whitebook (diário), iClinic (diário), ReceitaPro (diário)
**Entrevistador:** Pesquisador UX — Equipe Cross AI, Afya SPM

---

**Entrevistador:** Carolina, obrigado por aceitar participar. Pode começar me contando como é o seu dia típico de atendimento?

**Dr. Carolina:** Claro. Eu atendo em média 18 pacientes por dia, consultas de 20 minutos. Chego às 7h30 no consultório, abro o iClinic para ver a agenda do dia, e já começo a me preparar mentalmente. Às 8h começa o primeiro paciente. Entre uma consulta e outra, tenho uns 2-3 minutos para fazer anotações. No final do dia, fico mais uns 40 minutos fechando prontuários que ficaram pendentes.

**Entrevistador:** E como o Whitebook entra nessa rotina?

**Dr. Carolina:** O Whitebook é meu braço direito. Eu consulto praticamente em todas as consultas. Não porque eu não saiba — é que a medicina muda rápido demais. Semana passada mesmo, um paciente veio com uma interação medicamentosa que eu não tinha certeza. Abri o Whitebook, pesquisei, e em 30 segundos tinha a resposta com a referência. Isso me dá segurança para tomar a decisão na hora, na frente do paciente.

**Entrevistador:** Você usa mais a busca tradicional ou o assistente de IA, o WBIA?

**Dr. Carolina:** Uso os dois, mas de formas diferentes. A busca tradicional eu uso quando sei exatamente o que estou procurando — tipo, quero a dose de amoxicilina para sinusite. É direto. O WBIA eu uso quando tenho uma dúvida mais complexa, tipo "paciente com insuficiência renal pode usar esse anti-inflamatório?". Aí eu preciso de uma resposta contextualizada, não só um número.

**Entrevistador:** E como tem sido a experiência com o WBIA?

**Dr. Carolina:** Olha, melhorou muito nos últimos meses. Mas ainda tenho ressalvas. A resposta em si geralmente é boa — o problema é que às vezes eu não consigo verificar de onde veio a informação. Quando aparece a citação inline, tipo "segundo o protocolo tal", eu fico tranquila. Mas quando a resposta vem sem referência, eu fico... desconfiada. Não é que eu ache que está errado, é que eu preciso poder falar para o paciente "segundo a diretriz X". Se eu não posso citar, eu não uso.

**Entrevistador:** Isso é muito importante. Pode me dar um exemplo concreto?

**Dr. Carolina:** Semana passada, perguntei sobre o manejo de hipertensão em gestante. A resposta veio certinha — metildopa como primeira linha, nifedipino como alternativa, evitar IECA. Tudo correto. Mas a citação estava só no primeiro parágrafo. O segundo parágrafo sobre nifedipino não tinha referência nenhuma. Aí eu pensei: "será que isso é do protocolo brasileiro ou do americano?". Faz diferença. Acabei indo buscar manualmente no UpToDate, que é pago e mais lento, mas tinha a referência completa. Perdi 5 minutos que não precisava ter perdido.

**Entrevistador:** Entendi. E sobre a busca do Whitebook em geral, como você avalia?

**Dr. Carolina:** A busca melhorou absurdamente. Antes eu digitava "amoxicilina criança otite" e vinham resultados meio aleatórios. Agora é muito mais preciso. A feature que eu mais gosto é aquela de perguntas relacionadas — o "Also Asked". Tipo, eu pesquiso sobre tratamento de ITU e aparecem perguntas como "Qual a duração do tratamento em gestantes?" e "Quando solicitar urocultura?". Isso é genial porque me faz pensar em coisas que eu não tinha pensado. Já aconteceu de eu mudar a conduta por causa de uma pergunta sugerida.

**Entrevistador:** Ótimo. Agora vamos falar do iClinic. Como é a sua experiência no dia a dia?

**Dr. Carolina:** O iClinic é essencial. Não consigo imaginar meu consultório sem ele. Agenda, prontuário, financeiro — tudo ali. Mas tem coisas que me incomodam profundamente.

**Entrevistador:** O que te incomoda?

**Dr. Carolina:** Primeiro: a transcrição. Eu amo a ideia de falar e o sistema transcrever. Mas na prática... olha, funciona bem para coisas simples. "Paciente refere dor em região epigástrica há 3 dias." Perfeito, transcreve certinho. Mas quando eu falo termos mais específicos, tipo "esofagogastroduodenoscopia" ou "anticoagulação com rivaroxabana", ele escreve qualquer coisa. Outro dia saiu "riva roxana" — com espaço no meio, como se fosse nome de pessoa. Aí eu preciso corrigir manualmente, e isso consome tempo. Se eu vou gastar tempo corrigindo, quase melhor digitar direto.

**Entrevistador:** Com que frequência isso acontece?

**Dr. Carolina:** Eu diria que em 30% das consultas eu preciso corrigir algo significativo na transcrição. E não é erro de português — é erro de terminologia médica. O sistema não reconhece termos que eu uso 10 vezes por dia. Isso me frustra porque mostra que a IA não foi treinada com vocabulário médico brasileiro suficiente. Parece que funciona bem para inglês e adaptaram para português, mas os termos clínicos em PT-BR ficaram de fora.

**Entrevistador:** E o prontuário em si, como você usa?

**Dr. Carolina:** Eu tenho meus modelos prontos. Anamnese estruturada, exame físico, hipótese diagnóstica, plano terapêutico. O iClinic permite criar modelos, e isso economiza muito tempo. Mas sabe o que falta? Falta o prontuário sugerir coisas. Tipo, se eu escrevo "diabetes tipo 2", o sistema poderia sugerir: "Deseja adicionar: HbA1c, glicemia de jejum, perfil lipídico?" Porque eu SEMPRE peço esses exames. É previsível. Mas o sistema não aprende meu padrão.

**Entrevistador:** Inteligência preditiva no prontuário.

**Dr. Carolina:** Exatamente. O iClinic tem todos os meus dados — 3 anos de consultas. Ele sabe que para diabetes eu sempre peço os mesmos exames. Mas não me sugere nada. É como ter um assistente que está presente em todas as consultas mas nunca aprende nada.

**Entrevistador:** Vamos falar da prescrição agora. Como é com o ReceitaPro?

**Dr. Carolina:** A prescrição digital foi uma revolução. Acabou com a caligrafia ilegível, acabou com a dúvida na farmácia. Isso é indiscutível. Mas o ReceitaPro tem lacunas que me fazem perder tempo todo santo dia.

**Entrevistador:** Pode detalhar?

**Dr. Carolina:** A calculadora de posologia para pediatria. Eu atendo crianças — 30% dos meus pacientes são pediátricos. Toda vez que preciso calcular dose por peso, eu pego a calculadora do celular. Dose em mg/kg, multiplicar pelo peso da criança, dividir pela concentração do xarope, arredondar para uma medida prática. Isso leva 2-3 minutos por prescrição. Se eu atendo 5 crianças por dia, são 15 minutos por dia perdidos fazendo conta de cabeça. O ReceitaPro deveria fazer isso automaticamente. Eu coloco o peso da criança, seleciono a medicação, e ele me diz: "5ml de 8 em 8 horas por 7 dias". Pronto.

**Entrevistador:** E a busca de medicamentos?

**Dr. Carolina:** Funciona, mas às vezes eu lembro o nome comercial e outras vezes o princípio ativo. Quando busco por princípio ativo, os resultados são bons. Mas quando busco por nome comercial de genérico, às vezes não encontra. Tipo, eu digito "clavulin" e ele não acha, mas se eu digitar "amoxicilina + clavulanato" funciona. O médico pensa em nome comercial no dia a dia — a busca precisa entender os dois.

**Entrevistador:** E os modelos de prescrição prontos?

**Dr. Carolina:** Ah, eu uso muito. Tenho modelo para "ITU feminina", "sinusite aguda", "hipertensão estágio 1". Economiza tempo. Mas sabe o que seria incrível? Se o sistema sugerisse modelos baseados no diagnóstico que eu acabei de escrever no prontuário. Eu escrevo "sinusite aguda" no iClinic, e quando abro o ReceitaPro, ele já oferece: "Deseja usar o modelo de sinusite aguda?" Com a prescrição pré-montada para eu revisar e ajustar. Hoje eu preciso ir lá, buscar o modelo, abrir, e aplicar manualmente. São 3 cliques que poderiam ser zero.

**Entrevistador:** Você sente que os três produtos conversam entre si?

**Dr. Carolina:** Parcialmente. O iClinic e o ReceitaPro têm uma integração razoável — eu prescrevo dentro do iClinic. Mas o Whitebook é completamente separado. Se eu estou no Whitebook consultando a dose de uma medicação, eu preciso copiar essa informação e colar manualmente na prescrição. Não tem integração. O sonho seria: eu consulto a dose no Whitebook, clico em "prescrever isso", e ele abre o ReceitaPro com a medicação já preenchida. Isso economizaria uns 20 cliques por dia.

**Entrevistador:** Se pudesse mudar uma coisa em cada produto, o que mudaria?

**Dr. Carolina:** Whitebook: citação inline em 100% das respostas do WBIA. Sem exceção. Se a IA não sabe de onde veio a informação, ela deveria dizer "não tenho referência para isso" em vez de responder sem citar.

iClinic: transcrição que entende vocabulário médico em PT-BR. Não precisa ser perfeita — precisa acertar os termos que eu uso todo dia.

ReceitaPro: calculadora de posologia pediátrica automática. É a feature que mais me faria economizar tempo no dia a dia.

**Entrevistador:** Última pergunta: você já considerou trocar para um concorrente?

**Dr. Carolina:** Já olhei o Amigo Tech quando eles me ligaram oferecendo. Mas sabe o que me segura? Já tenho 3 anos de prontuários no iClinic. Migrar é um pesadelo. E o Whitebook, ninguém faz igual em português. O UpToDate é bom, mas é em inglês e caro. Então eu fico. Mas fico reclamando. E se aparecer alguém que resolva esses 3 problemas que eu falei... aí eu penso duas vezes.

**Entrevistador:** Carolina, muito obrigado pelo tempo. Esses insights são valiosos demais.

**Dr. Carolina:** Imagina. Se vocês resolverem a calculadora de posologia, me avisem que eu faço um review 5 estrelas no mesmo dia.

---
*Entrevista encerrada. 58 minutos.*
