# Transcrição de Entrevista — Dr. Thiago Nascimento

**Data:** 16/05/2026
**Duração:** 61 minutos
**Perfil:** Endocrinologista, 39 anos, clínica própria no RJ (Botafogo), 14 anos de formado
**Produtos:** Whitebook (diário), iClinic (diário), ReceitaPro (diário)
**Entrevistador:** Pesquisador UX — Equipe Cross AI, Afya SPM

---

**Entrevistador:** Thiago, me conta sobre sua prática.

**Dr. Thiago:** Sou endocrinologista focado em diabetes e tireoide. Atendo 14 pacientes por dia — consulta de 30 a 45 minutos, porque endócrino é muito de acompanhamento longitudinal. Tenho pacientes que acompanho há 8 anos. Cada consulta é uma atualização do plano terapêutico baseada em exames novos. Eu vivo de dados — HbA1c, TSH, glicemia, perfil lipídico. Meu trabalho é interpretar números e ajustar medicação.

**Entrevistador:** E como os produtos da Afya apoiam esse trabalho?

**Dr. Thiago:** O iClinic é onde tudo acontece. Prontuário, agenda, financeiro. Eu sou heavy user — tenho modelos customizados para cada tipo de consulta. Modelo de primeira consulta de diabetes, modelo de retorno de diabetes, modelo de tireoide, modelo de obesidade. Cada um com campos específicos. Isso funciona muito bem.

**Entrevistador:** O que não funciona?

**Dr. Thiago:** O iClinic não entende que medicina é longitudinal. Eu preciso ver a evolução do paciente ao longo do tempo. HbA1c em janeiro: 8,2%. Em abril: 7,5%. Em julho: 7,1%. Essa tendência é o que importa — não o número isolado. Mas o iClinic não tem uma visão de timeline. Eu preciso abrir consulta por consulta e anotar os números manualmente para ver a evolução. Já sugeri um dashboard do paciente com gráficos de evolução dos principais marcadores. Resposta: "está no roadmap."

**Entrevistador:** Outro sistema resolve isso?

**Dr. Thiago:** O Glic, que é específico para diabetes, tem. Mas ele é só para diabetes — não tem prontuário completo, não tem agenda, não tem financeiro. Então eu uso o iClinic para tudo e o Glic para acompanhar glicemia. Dois sistemas que não conversam. É absurdo.

**Entrevistador:** E o Whitebook na sua rotina?

**Dr. Thiago:** Uso bastante para atualização. Endocrinologia muda a cada congresso. O guideline de diabetes da ADA muda todo ano em janeiro. O Whitebook geralmente atualiza rápido — em 2-3 semanas já tem o resumo. Isso me economiza ler 200 páginas de guideline. Mas preciso confiar que a atualização está lá. E às vezes não está.

**Entrevistador:** Pode dar um exemplo?

**Dr. Thiago:** Em janeiro de 2026, saiu a atualização da ADA sobre uso de tirzepatida como primeira linha para diabetes tipo 2 com obesidade. Fui buscar no Whitebook em fevereiro — ainda não tinha. Fui pro WBIA e perguntei. A resposta mencionava a tirzepatida, mas citava o guideline de 2025, não o de 2026. Ou seja, a IA não sabia que existia uma atualização. Isso é perigoso porque me dá uma falsa sensação de que estou atualizado quando na verdade estou seguindo guideline do ano passado.

**Entrevistador:** A citação mostrava que era de 2025?

**Dr. Thiago:** Sim, e por isso eu percebi. Se não tivesse citação, eu teria seguido a recomendação antiga sem saber. Então paradoxalmente, a citação me salvou — porque me mostrou que a informação estava desatualizada. Isso reforça: citação não é opcional, é segurança.

**Entrevistador:** E quando a resposta do WBIA é boa?

**Dr. Thiago:** Quando funciona, é fantástico. Mês passado perguntei sobre ajuste de dose de insulina basal em paciente com hipoglicemias noturnas recorrentes. A resposta veio com o protocolo certinho: reduzir 10-20% da dose, considerar troca para insulina de segunda geração, verificar se está comendo antes de dormir. E veio com citação do Standards of Medical Care da ADA. Perfeito. Imprimi e colei no prontuário.

**Entrevistador:** Vamos falar de prescrição. Como é para endocrinologia?

**Dr. Thiago:** Endocrinologia é complexa em prescrição porque muitos medicamentos têm titulação. Metformina: começa com 500mg, sobe para 850mg, depois 1000mg. Insulina: começa com 10 unidades, ajusta de 2 em 2 a cada 3 dias. Eu preciso que a prescrição reflita esse plano de titulação, não só a dose atual.

**Entrevistador:** O ReceitaPro permite isso?

**Dr. Thiago:** Não. Eu prescrevo a dose atual e verbalmente explico a titulação para o paciente. Mas deveria haver uma forma de prescrever um "plano de dose" — tipo: "Metformina 500mg por 7 dias, depois 850mg por 7 dias, depois 1000mg contínuo." Isso reduziria a necessidade de retorno precoce só para aumentar dose. E daria mais autonomia ao paciente.

**Entrevistador:** E sobre alertas de interação no ReceitaPro?

**Dr. Thiago:** Inexistentes no meu uso. E olha que eu prescrevo combinações que precisam de cuidado. Metformina com contraste iodado — precisa suspender 48h antes do exame. Sulfonilureias com betabloqueadores — mascara hipoglicemia. Levotiroxina com cálcio — reduz absorção se tomados juntos. Nenhum desses alertas aparece. Eu sei disso porque tenho 14 anos de prática. Mas um R3 de endócrino poderia facilmente cometer esses erros.

**Entrevistador:** Sobre a IA de forma geral — o que te faz confiar?

**Dr. Thiago:** Três coisas. Primeiro: citação com ano. Se cita "ADA 2026", eu confio. Se não cita, não confio. Segundo: admitir quando não sabe. Prefiro mil vezes que a IA diga "não tenho informação atualizada sobre isso" do que invente uma resposta plausível. Terceiro: me mostrar quando algo mudou. Se o guideline de 2026 contradiz o de 2025, me avise explicitamente: "Atenção: a recomendação mudou em janeiro de 2026."

**Entrevistador:** Sobre integração entre os produtos?

**Dr. Thiago:** Vou te dar o cenário dos sonhos. Paciente chega com HbA1c de 8,5%. Eu registro no iClinic. O sistema cruza com as últimas 3 HbA1c (7,8%, 8,0%, 8,5%) e me mostra: "tendência de piora progressiva." Automaticamente sugere: "Segundo ADA 2026, para HbA1c >8% com metformina máxima, considerar adicionar agonista GLP-1 ou SGLT2i." E quando eu seleciono a semaglutida, o ReceitaPro já abre com a prescrição de titulação: 0,25mg por 4 semanas, depois 0,5mg por 4 semanas, depois 1mg contínuo. Tudo em 3 cliques. Hoje, esse processo leva 15 minutos de consultar Whitebook, calcular, montar a prescrição manualmente, explicar a titulação.

**Entrevistador:** Isso é IA contextual no nível que vocês ainda não entregam.

**Dr. Thiago:** Exato. E é o que diferenciaria vocês de qualquer concorrente. Ninguém tem os três pilares juntos: referência médica + prontuário + prescrição. A Afya tem. Só precisa conectar.

**Entrevistador:** Se pudesse mudar uma coisa em cada produto?

**Dr. Thiago:** Whitebook WBIA: garantir que guidelines recentes estejam na base dentro de 30 dias após publicação. Não pode ter lag de meses.

iClinic: dashboard longitudinal do paciente com gráfico de evolução dos marcadores ao longo do tempo.

ReceitaPro: prescrição com plano de titulação, não só dose única.

**Entrevistador:** Última pergunta: já indicou os produtos para colegas?

**Dr. Thiago:** Indico o Whitebook para todo mundo. É o melhor produto da Afya, disparado. iClinic eu indico com ressalvas. ReceitaPro eu digo que é bom mas incompleto. O pacote completo é bom — mas "bom" não é suficiente quando você compete com Amigo Tech prometendo maravilhas. Vocês precisam ir de "bom" para "indispensável." E o caminho para indispensável é integração + personalização por especialidade.

---
*Entrevista encerrada. 61 minutos.*
