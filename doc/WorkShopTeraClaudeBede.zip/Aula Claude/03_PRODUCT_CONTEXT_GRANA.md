# Contexto de Produto — App Grana

## O Produto
App de saúde financeira para jovens adultos (22-35 anos). Ajuda a sair do vermelho, construir reserva de emergência e desenvolver hábitos financeiros saudáveis. Diferencial: metas automatizadas via Open Banking e educação financeira contextual (no momento certo, não em curso genérico).

## Nossas Personas Principais

### Lucas — O Endividado Esperançoso
- 27 anos, analista de marketing, CLT, R$4.500/mês
- Deve R$8.000 no cartão (parcelou eletrônicos e viagens)
- Já tentou planilha, desistiu em 2 semanas
- Quer: "sair do vermelho sem sentir que estou me punindo"
- JTBD: "Quando recebo o salário, preciso de um plano automático para pagar dívidas sem eu precisar pensar"

### Mariana — A Poupadora Insegura
- 30 anos, UX designer, PJ, renda variável R$5-9k/mês
- Não tem dívidas mas não tem reserva de emergência
- Medo de investir porque "não entende nada disso"
- Quer: "guardar dinheiro sem precisar virar especialista em finanças"
- JTBD: "Quando sobra dinheiro no mês, preciso de um lugar seguro pra colocar sem precisar pesquisar"

### Rafael — O Comparador Técnico
- 24 anos, desenvolvedor júnior, R$3.800/mês
- Usa Grana e Mobills ao mesmo tempo
- Quer mais visibilidade do progresso durante o mês
- JTBD: "Quando estou no meio do mês, preciso saber em tempo real se estou no caminho certo"

## Métricas Atuais (Maio 2026)
- MAU: 180k
- MAU com meta ativa: 42k (23% dos MAU)
- Taxa de conclusão de meta: 23%
- Churn D30: 38% (problema principal)
- NPS: 47
- Ticket médio de depósito: R$320/mês
- CAC: R$22 | LTV: R$186 | LTV/CAC: 8.5x

## Decisões Recentes
- Abr/26: Lançamos integração Open Banking — automação de categorização de gastos
- Mar/26: Pivotamos de "app de investimento" para "app de saúde financeira"
- Fev/26: Cortamos feature de social (ranking entre amigos) — métricas não justificavam
- Jan/26: Identificamos que 62% do churn D30 acontece porque o usuário não configura a 1ª meta

## Competidores
| Competidor | Ameaça | Diferencial deles | Nosso diferencial |
|------------|--------|-------------------|-------------------|
| Nubank | Alta | Ecossistema completo (conta, cartão, investimento) | Foco exclusivo em comportamento financeiro |
| Mobills | Média | Maior base BR de controle financeiro | UX mais simples + metas automatizadas |
| Organizze | Baixa | Marca forte em educação financeira | Automação real (Open Banking) |
| GuiaBolso | Baixa | Pioneiro em Open Banking BR | UX moderna + foco em jovens |

## O Que NÃO É Nosso Produto
- Não somos banco (não oferecemos conta ou cartão)
- Não somos app de investimento (não vendemos produtos financeiros)
- Não somos consultoria financeira (não damos aconselhamento personalizado)
- Somos ferramenta de mudança de comportamento financeiro
