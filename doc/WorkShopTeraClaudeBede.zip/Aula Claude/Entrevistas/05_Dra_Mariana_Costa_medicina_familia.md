# Transcrição de Entrevista — Dra. Mariana Costa

**Data:** 16/05/2026
**Duração:** 57 minutos
**Perfil:** Médica de família e comunidade, 29 anos, atende em UBS (manhã) e consultório particular (tarde) em Porto Alegre, 4 anos de formada
**Produtos:** Whitebook (diário), iClinic (diário, particular), ReceitaPro (diário)
**Entrevistador:** Pesquisador UX — Equipe Cross AI, Afya SPM

---

**Entrevistador:** Mariana, você tem uma rotina bem particular — atende em dois contextos diferentes. Conta pra gente.

**Dra. Mariana:** Sim. De manhã atendo na UBS — posto de saúde público. Lá são 20-25 pacientes em 4 horas. Consultas de 10-12 minutos. Pressão enorme. De tarde, atendo no meu consultório particular com iClinic — 8 pacientes em 4 horas, consultas de 25-30 minutos. São dois mundos completamente diferentes. Mas em ambos eu uso o Whitebook no celular. É meu companheiro constante.

**Entrevistador:** Como o Whitebook te ajuda na UBS?

**Dra. Mariana:** Na UBS eu sou generalista — atendo de tudo. Criança com febre, gestante com pré-eclâmpsia, idoso com diabetes descompensado, adolescente com depressão. A amplitude é absurda. Eu não consigo dominar tudo. O Whitebook é minha rede de segurança. Quando aparece algo que não domino, abro o app e em 30 segundos tenho a conduta. Semana passada atendi um caso de herpes zóster em paciente imunossuprimido — não é meu dia a dia. Abri o Whitebook, vi o protocolo, prescevi aciclovir na dose correta. Sem o Whitebook, teria encaminhado para o dermatologista e o paciente esperaria 3 meses pelo SUS.

**Entrevistador:** E o WBIA na UBS?

**Dra. Mariana:** Na UBS eu não tenho tempo para o WBIA. São 10 minutos por consulta. Preciso de resposta em 10 segundos, não em 30. A busca direta é mais rápida para informação pontual. O WBIA eu uso mais à tarde, no consultório particular, quando tenho tempo para fazer uma pergunta mais elaborada e ler a resposta com calma.

**Entrevistador:** Então o WBIA é mais para o contexto de consulta longa?

**Dra. Mariana:** Sim. E isso não é defeito — é que a IA conversacional demanda um tipo de interação que não cabe em consulta de 10 minutos. Sabe o que funcionaria na UBS? IA proativa. Em vez de eu perguntar, o sistema me sugerir. Tipo: eu digito no prontuário "gestante 32 semanas com PA 150/100" e a IA me alerta: "Atenção: considerar pré-eclâmpsia. Protocolo: solicitar proteinúria, avaliar sinais de gravidade." Sem eu pedir. Porque na correria da UBS, eu posso esquecer de verificar algo. A IA proativa seria minha copiloto silenciosa.

**Entrevistador:** Isso é interessante — IA proativa vs. reativa. E no consultório particular com iClinic?

**Dra. Mariana:** No particular é outra vida. Tenho tempo para usar tudo. O iClinic é meu prontuário, minha agenda, meu financeiro. Funciona bem no geral. Mas tenho três reclamações específicas.

**Entrevistador:** Pode listar?

**Dra. Mariana:** Uma: a agenda não é inteligente. Eu tenho pacientes que precisam de consulta de 15 minutos (retorno simples) e outros que precisam de 45 minutos (primeira consulta complexa). Mas a agenda trata todos iguais — slots de 30 minutos. Deveria sugerir o tempo baseado no tipo de consulta e no histórico do paciente.

Dois: o prontuário não tem resumo automático. Eu tenho pacientes que acompanho há 3 anos. São 15-20 consultas registradas. Quando preciso ver o histórico antes de atender, abro consulta por consulta. Um resumo automático seria incrível: "Paciente com DM2 desde 2023, em uso de metformina 2g/dia, última HbA1c 7,2% em março/26, alérgica a sulfa." Isso em vez de eu ler 20 prontuários para montar o quadro mental.

Três: a transcrição. Funciona para coisas simples. Mas quando eu falo "prescrevo losartana 50mg uma vez ao dia" e ela transcreve "prescrevo losartan a 50 mg uma vez ao dia" — com espaço errado e nome em inglês — eu preciso corrigir. Parece pouco, mas em 8 consultas por dia, são 8 correções de 30 segundos cada = 4 minutos perdidos. Somando com as outras correções de termos médicos, chega a 10-15 minutos por dia.

**Entrevistador:** E o ReceitaPro?

**Dra. Mariana:** Eu amo o ReceitaPro. Sério. A prescrição digital mudou minha vida. Acabou com o "doutora, o farmacêutico não entendeu sua letra." Mas sim, falta a calculadora de posologia para crianças. Eu atendo crianças também — medicina de família é isso. E toda vez é conta no celular.

Outra coisa: falta prescrição de exames complementares integrada. Eu prescrevo medicamento no ReceitaPro, mas solicito exames num bloco de papel separado. Por que não tem solicitação de exames no mesmo fluxo? Eu prescrevo metformina E solicito HbA1c. São parte do mesmo ato médico. Deveriam estar no mesmo lugar.

**Entrevistador:** E a busca de medicamentos?

**Dra. Mariana:** Funciona bem para medicamentos comuns. Mas para fitoterápicos e medicamentos da RENAME — que é a lista do SUS — é fraco. Na UBS eu prescrevo muito pela RENAME. Quando busco "dipirona solução oral 500mg/ml" no ReceitaPro, às vezes não encontra na apresentação do SUS. Encontra a apresentação comercial mas não a genérica da farmácia básica. Para quem atende no SUS, isso é um gap importante.

**Entrevistador:** Sobre confiança na IA — como você se sente?

**Dra. Mariana:** Eu sou da geração que cresceu com IA. Não tenho medo. Mas tenho critério. Uso o ChatGPT pessoalmente, uso o Claude para estudar, uso o WBIA no trabalho. A diferença é: para uso pessoal, aceito erro. Para uso clínico, não aceito. Então o que me faz confiar no WBIA é a citação. Quando vem citado, eu sei que a informação veio de uma fonte curada. Quando não vem citado, eu trato como "sugestão de um colega" — ouço, mas verifico.

**Entrevistador:** O que te faria usar mais o WBIA?

**Dra. Mariana:** Duas coisas. Primeiro: velocidade. No consultório particular, tudo bem esperar 15 segundos por uma resposta. Na UBS, eu preciso em 5 segundos. Se o WBIA tivesse um modo "resposta rápida" — tipo, só a conduta principal em uma linha, sem explicação — eu usaria lá.

Segundo: proatividade. Eu já falei: em vez de eu perguntar, o sistema sugerir. Baseado no que eu escrevo no prontuário, a IA me alerta sobre coisas que eu posso estar esquecendo. Não é substituir meu julgamento — é aumentar minha atenção. Em 10 minutos de consulta, é fácil esquecer de perguntar sobre alergia a medicamento, ou de verificar se a gestante fez o teste de tolerância à glicose. A IA proativa seria como ter um R2 sentado do meu lado anotando tudo.

**Entrevistador:** E a integração entre os três produtos?

**Dra. Mariana:** É o maior gap. Eu uso três apps diferentes para o mesmo paciente. Whitebook no celular, iClinic no computador, ReceitaPro dentro do iClinic mas desconectado do Whitebook. Se eu pudesse, do iClinic, clicar em um diagnóstico e ver o protocolo do Whitebook sem sair da tela — já seria uma revolução. E se ao criar a prescrição, o sistema sugerisse exames complementares de acompanhamento automaticamente — tipo, prescreveu estatina, sugere: "Solicitar TGO/TGP em 30 dias" — isso seria transformador.

**Entrevistador:** Se pudesse mudar uma coisa em cada produto?

**Dra. Mariana:** Whitebook: modo "resposta rápida" do WBIA para consultas curtas. Uma linha, sem explicação, com link para o protocolo completo se eu quiser.

iClinic: resumo automático do paciente baseado em todas as consultas anteriores. "Me diz em 3 linhas quem é esse paciente e o que está acontecendo."

ReceitaPro: solicitação de exames complementares integrada ao fluxo de prescrição.

**Entrevistador:** E se tivesse que escolher a mais impactante?

**Dra. Mariana:** Resumo automático do paciente no iClinic. Porque isso me economiza tempo em CADA consulta de CADA paciente de acompanhamento. É o maior multiplicador de produtividade que eu consigo imaginar. E os dados já estão lá — o iClinic tem todas as consultas anteriores. Só precisa sintetizar.

**Entrevistador:** Última pergunta: o que te faria indicar os produtos Afya sem nenhuma ressalva?

**Dra. Mariana:** Quando eu sentir que os produtos me conhecem. Que sabem que eu sou médica de família, que atendo crianças e adultos, que trabalho tanto no SUS quanto no particular. Hoje, o sistema trata todo médico igual. Eu não sou igual ao cardiologista, que não é igual ao pediatra. Personalização por perfil e por contexto de atendimento. Quando vocês resolverem isso, eu viro embaixadora.

---
*Entrevista encerrada. 57 minutos.*
