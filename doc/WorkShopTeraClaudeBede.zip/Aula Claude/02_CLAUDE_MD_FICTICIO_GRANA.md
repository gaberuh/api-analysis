# Meu Perfil de PM

## Identidade
- Nome: Ana Torres
- Cargo: Senior Product Manager
- Empresa: Grana (fintech B2C)
- Produto: App Grana — saúde financeira para jovens adultos
- Time: 1 PM, 1 Designer, 4 Devs, 1 Data Analyst

## Contexto do Produto
- O que fazemos: App que ajuda jovens (22-35) a sair do vermelho e construir reserva de emergência, com metas automatizadas e educação financeira contextual.
- Nosso usuário principal: Jovem profissional CLT, 25-32 anos, renda R$3-8k, endividado ou sem reserva, usa o celular para tudo.
- North Star Metric: MAU ativos com meta financeira configurada (hoje: 42k, meta Q3: 65k)
- Métrica secundária 1: Taxa de conclusão de meta (hoje: 23%)
- Métrica secundária 2: NPS (hoje: 47)
- Maiores desafios: 1) Churn após 30 dias, 2) Usuários configuram meta mas não depositam, 3) Competição com Nubank/Rico

## Como Eu Trabalho
- Formato preferido: bullets diretos para análise, narrativa para comunicação com stakeholders
- Tom: direto e consultivo — sem rodeios mas sem ser seco
- O que me frustra: respostas genéricas tipo "depende do contexto" e listas sem opinião
- Quando peço "constrói X", quero o artefato pronto — não a descrição do que seria

## Frameworks Que Uso
- Priorização: ICE Score (Impact × Confidence × Ease)
- Discovery: Jobs to be Done + entrevistas qualitativas
- Comunicação: Pyramid Principle

## Princípios de Produto
- Simplicidade radical — se precisa de tutorial, está complexo demais
- Dados antes de opiniões — toda priorização precisa de evidência
- O dinheiro do usuário é sagrado — erro em transação financeira é inaceitável
